package com.avantplus.fintracker.utils;

public class FintrackerConstants {
	public static final byte CATEGORY_DUPLICATE_ERR_CODE = -1;
	public static final byte SUBCATEGORY_DUPLICATE_ERR_CODE = -1;
	public static final byte PAYMENT_DUPLICATE_ERR_CODE = -1;
}
