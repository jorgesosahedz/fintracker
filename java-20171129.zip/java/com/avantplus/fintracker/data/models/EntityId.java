package com.avantplus.fintracker.data.models;

public class EntityId {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

}
